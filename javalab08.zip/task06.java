import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class task06{

    public static void main(String[] args) {
        int[] numbers = new int[100];
        Random random = new Random();

        Map<Integer, Integer> frequencyMap = new HashMap<>();

        for (int i = 0; i < numbers.length; i++) {
            int num = random.nextInt(21); 
            numbers[i] = num;
            frequencyMap.put(num, frequencyMap.getOrDefault(num, 0) + 1);
        }


        System.out.println("Frequency of numbers between 0 and 20:");
        for (int i = 0; i <= 20; i++) {
            int freq = frequencyMap.getOrDefault(i, 0);
            System.out.println(i + " → " + freq);
        }
    }
}
