public class task01 {

    public static String reverseString(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        char[] reversed = new char[str.length()];
        int lastIndex = str.length() - 1;

        for (int i = 0; i < str.length(); i++) {
            reversed[i] = str.charAt(lastIndex - i);
        }

        return new String(reversed);
    }

    public static void main(String[] args) {
        String input = "hello";
        String output = reverseString(input);
        System.out.println("Reversed: " + output); 
    }
}
