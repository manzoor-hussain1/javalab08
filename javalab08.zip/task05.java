import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class task05 {

    public static int generateRandomPrime(int min, int max) {
        if (min > max) {
            throw new IllegalArgumentException("min should not be greater than max.");
        }

        List<Integer> primes = new ArrayList<>();

        for (int i = min; i <= max; i++) {
            if (isPrime(i)) {
                primes.add(i);
            }
        }

        if (primes.isEmpty()) {
            throw new IllegalArgumentException("No prime numbers found in the given range.");
        }
        Random rand = new Random();
        return primes.get(rand.nextInt(primes.size()));
    }
    private static boolean isPrime(int num) {
        if (num < 2) return false;
        for (int i = 2; i <= Math.sqrt(num); i++) {
            if (num % i == 0) return false;
        }
        return true;
    }

    public static void main(String[] args) {
        int min = 10;
        int max = 20;
        int randomPrime = generateRandomPrime(min, max);
        System.out.println("Random Prime: " + randomPrime);
    }
}
